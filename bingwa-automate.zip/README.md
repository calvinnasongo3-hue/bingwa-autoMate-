# Bingwa autoMate
Deploy to Render, then configure Safaricom Daraja callback URL to /mpesa/callback.
